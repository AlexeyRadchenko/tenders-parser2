from enum import Enum, auto

class Modification(Enum):
    Total = auto()
    Calendar = auto()
    Help = auto()
    CurUSD = auto()
    CurRUB = auto()
    CurEUR = auto()
    HiddenLabel = auto()
    ProductSearch = auto()
    Email = auto()