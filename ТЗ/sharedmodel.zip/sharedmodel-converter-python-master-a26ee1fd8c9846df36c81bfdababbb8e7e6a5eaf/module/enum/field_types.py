from enum import Enum, auto

class FieldType(Enum):
    Nothing = auto()
    Integer = auto()
    String = auto()
    DateTime = auto()
    Date = auto()
    Price = auto()
    Array = auto()
    Bool = auto()
    Object = auto()